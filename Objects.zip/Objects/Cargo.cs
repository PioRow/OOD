﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOD.Objects
{
    public class Cargo
    {
        private long _id;
        private float _weight;
        private string _code;
        private string _description;
        public Cargo(long id, float weight, string code, string description)
        {
            _id = id;
            _weight = weight;
            _code = code;
            _description = description;
        }
    }
}
