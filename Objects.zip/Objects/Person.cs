﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOD.Objects
{
    public class Person
    {
        protected long _id;
        protected string _name;
        protected long _age;
        protected string _phone;
        protected string _email;
        public Person(long id, string name, long age, string phone, string email)
        {
            _id = id;
            _name = name;
            _age = age;
            _phone = phone;
            _email = email;
        }
    }
}
