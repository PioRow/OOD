﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOD.Objects
{
    public class Plane
    {
        protected long _id;
        protected string _serial;
        protected string _code;
        protected string _model;
        public Plane(long id, string serial, string code, string model)
        {
            _id = id;
            _serial = serial;
            _code = code;
            _model = model;
        }
    }
}
