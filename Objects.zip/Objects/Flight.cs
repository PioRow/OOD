﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOD.Objects
{
    public class Flight
    {
        private long _id;
        private long _orginId;
        private long _targetId;
        private string _takeoffTime;
        private string _landingTime;
        private float _longitude;
        private float _latitude;
        private float _amsl;
        private long _planeId;
        private List<long> _crewIds;
        private List<long> _loadIds;
        public Flight(long id, long orginId, long targetId, string takeoffTime, string landingTime, float longitude, 
            float latitude, float amsl, long planeId, List<long> crewIds, List<long> loadIds)
        {
            _id = id;
            _orginId = orginId;
            _targetId = targetId;
            _takeoffTime = takeoffTime;
            _landingTime = landingTime;
            _longitude = longitude;
            _latitude = latitude;
            _amsl = amsl;
            _planeId = planeId;
            _crewIds = crewIds;
            _loadIds = loadIds;
        }
    }
}
