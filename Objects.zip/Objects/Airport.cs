﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOD.Objects
{
    public class Airport
    {
        private string _name;
        private string _code;
        private float _longitude;
        private float _latiitude;
        private float _amsl;
        private string _country;
        public Airport(string name, string code, float longitude, float latiitude, float amsl, string country)
        {
            _name = name;
            _code = code;
            _longitude = longitude;
            _latiitude = latiitude;
            _amsl = amsl;
            _country = country;
        } 
        
    }
}
